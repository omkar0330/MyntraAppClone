package com.example.myntraapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ProfileScreen() {
    Column(modifier = Modifier.fillMaxSize().background(Color.White)) {
        // Top Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(modifier = Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = MaterialTheme.shapes.medium, modifier = Modifier.size(60.dp)) {
                    Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.padding(12.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("BluMart User", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text("user@blumart.com", color = Color.White.copy(alpha = 0.8f))
                }
            }
        }

        // Menu Items
        Column(modifier = Modifier.padding(16.dp)) {
            ProfileOption(icon = Icons.Outlined.ShoppingBag, title = "Orders")
            ProfileOption(icon = Icons.Outlined.FavoriteBorder, title = "Wishlist")
            ProfileOption(icon = Icons.Outlined.CreditCard, title = "Saved Cards")
            ProfileOption(icon = Icons.Outlined.Settings, title = "Account Settings")
        }
    }
}

@Composable
fun ProfileOption(icon: ImageVector, title: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { }
            .padding(vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Color.Gray)
        Spacer(modifier = Modifier.width(16.dp))
        Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        Spacer(modifier = Modifier.weight(1f))
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.LightGray)
    }
    Divider(color = Color.LightGray.copy(alpha = 0.2f))
}
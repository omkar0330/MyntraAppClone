package com.example.myntraapp.model

// Category is now defined in DataRepository.kt for simplicity in this task.
// This file can be removed or kept empty if needed.

package com.example.myntraapp.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myntraapp.model.DataRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(onBack: () -> Unit) {
    var searchQuery by remember { mutableStateOf("") }
    val allProducts = remember { DataRepository.getProducts() }
    val filteredProducts = remember(searchQuery) {
        if (searchQuery.isEmpty()) emptyList()
        else allProducts.filter { it.name.contains(searchQuery, ignoreCase = true) || it.brand.contains(searchQuery, ignoreCase = true) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    TextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search for brands, products...", fontSize = 14.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            disabledContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                        ),
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = null)
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = null,
                                    modifier = Modifier.clickable { searchQuery = "" }
                                )
                            }
                        },
                        singleLine = true
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            if (searchQuery.isEmpty()) {
                // Show trending or recent searches
                Text(
                    "Trending Searches",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.titleSmall,
                    color = Color.Gray
                )
                // Add some dummy trending searches
                val trending = listOf("Shirts", "Jeans", "Roadster", "HRX", "Shoes")
                trending.forEach { item ->
                    ListItem(
                        headlineContent = { Text(item) },
                        modifier = Modifier.clickable { searchQuery = item }
                    )
                }
            } else {
                LazyColumn {
                    items(filteredProducts) { product ->
                        ListItem(
                            headlineContent = { Text(product.name) },
                            supportingContent = { Text(product.brand, color = Color.Gray) },
                            trailingContent = { Text(product.price) },
                            modifier = Modifier.clickable { /* Navigate to PDP */ }
                        )
                    }
                }
            }
        }
    }
}
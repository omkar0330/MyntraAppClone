package com.example.myntraapp.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.graphics.vector.ImageVector

data class Category(val id: Int, val name: String, val icon: ImageVector)
data class Banner(val id: Int, val imageUrl: String, val title: String? = null, val subtitle: String? = null)
data class Deal(val id: Int, val title: String, val price: String, val imageUrl: String)

object DataRepository {
    fun getCategories() = listOf(
        Category(1, "Fashion", Icons.Outlined.Checkroom),
        Category(2, "Beauty", Icons.Outlined.Brush),
        Category(3, "Home", Icons.Outlined.Home),
        Category(4, "Footwear", Icons.Outlined.ShoppingBag),
        Category(5, "Accessories", Icons.Outlined.Watch),
        Category(6, "Kids", Icons.Outlined.ChildCare)
    )

    fun getMainBanners() = listOf(
        Banner(1, "https://picsum.photos/seed/fashion_model/800/400", "OWN THE OCCASION", "Regal Looks To Own Spotlight"),
        Banner(2, "https://picsum.photos/seed/men_wear/800/400", "Valentine Edit", "STARTING ₹ 699")
    )

    fun getPromoBanners() = listOf(
        Banner(1, "https://picsum.photos/seed/promo_red/800/100", "FLAT ₹400 OFF"),
        Banner(2, "https://picsum.photos/seed/promo_cashback/800/100", "Flat 7.5% Cashback")
    )

    fun getMostLovedBargains() = listOf(
        Deal(1, "Kurtas", "Under ₹549", "https://picsum.photos/seed/shopping_kurta/300/400"),
        Deal(2, "Dresses", "Under ₹699", "https://picsum.photos/seed/shopping_dress/300/400"),
        Deal(3, "Shirts", "Under ₹649", "https://picsum.photos/seed/shopping_shirt/300/400"),
        Deal(4, "Casual Shoes", "Under ₹1249", "https://picsum.photos/seed/shopping_shoes/300/400")
    )
    
    private val brands = listOf("Roadster", "HRX", "H&M", "Puma", "Nike", "Adidas", "Levis", "WROGN", "ZARA", "Jack & Jones")
    private val productNames = listOf("Cotton Slim Fit Shirt", "Running Shoes", "Skinny Fit Jeans", "Round Neck T-Shirt", "Leather Jacket", "Casual Sneakers", "Denim Jacket", "Chino Trousers", "Polo T-Shirt", "Hooded Sweatshirt")

    fun getProducts() = List(20) { id ->
        Product(
            id = id,
            name = productNames[id % productNames.size],
            brand = brands[id % brands.size],
            price = "₹${(500..2500).random()}",
            imageUrl = "https://picsum.photos/seed/shop_item_${id + 50}/300/400",
            discount = "${(10..60).random()}% OFF"
        )
    }
}
package com.example.blumart.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.example.myntraapp.ui.theme.CoralAccent
import com.example.myntraapp.ui.theme.DarkText
import com.example.myntraapp.ui.theme.OceanBluePrimary
import com.example.myntraapp.ui.theme.SandBackground

private val LightColorScheme = lightColorScheme(
    primary = OceanBluePrimary,
    secondary = CoralAccent,
    background = SandBackground,
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = DarkText,
    onSurface = DarkText
)

@Composable
fun BluMartTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        content = content
    )
}
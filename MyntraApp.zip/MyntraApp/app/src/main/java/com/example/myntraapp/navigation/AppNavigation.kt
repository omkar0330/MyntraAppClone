package com.example.myntraapp.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.myntraapp.ui.screens.HomeScreen
import com.example.myntraapp.ui.screens.ProfileScreen
import com.example.myntraapp.ui.screens.SearchScreen
import com.example.myntraapp.ui.screens.ShopScreen

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    // Logic to determine selected tab
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            // Only show bottom bar on main screens
            if (currentRoute in listOf("home", "shop", "profile")) {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Home, contentDescription = null) },
                        label = { Text("Home") },
                        selected = currentRoute == "home",
                        onClick = { navController.navigate("home") }
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.ShoppingBag, contentDescription = null) },
                        label = { Text("Shop") },
                        selected = currentRoute == "shop",
                        onClick = { navController.navigate("shop") }
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Person, contentDescription = null) },
                        label = { Text("Profile") },
                        selected = currentRoute == "profile",
                        onClick = { navController.navigate("profile") }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("home") { 
                HomeScreen(onSearchClick = { navController.navigate("search") }) 
            }
            composable("shop") { ShopScreen() }
            composable("profile") { ProfileScreen() }
            composable("search") { 
                SearchScreen(onBack = { navController.popBackStack() }) 
            }
        }
    }
}
package com.example.myntraapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.myntraapp.model.DataRepository
import com.example.myntraapp.ui.components.SearchBar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onSearchClick: () -> Unit) {
    val scrollState = rememberScrollState()
    var selectedTab by remember { mutableStateOf("All") }
    val tabs = listOf("All", "Men", "Women", "Kids")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(Color(0xFFFFF8F9))
    ) {
        // 1. Top Bar: Deliver to ...
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Outlined.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "Deliver to 634X+RXQ...",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
            Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(16.dp))
        }

        // 2. Search Bar & Icons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFF3F6C)),
                contentAlignment = Alignment.Center
            ) {
                Text("M", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            
            Spacer(modifier = Modifier.width(12.dp))
            
            SearchBar(modifier = Modifier.weight(1f), hint = "Search for products")
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Icon(Icons.Outlined.Notifications, contentDescription = null, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Icon(Icons.Outlined.FavoriteBorder, contentDescription = null, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Icon(Icons.Outlined.Person, contentDescription = null, modifier = Modifier.size(22.dp))
        }

        // 3. Tab Categories
        Spacer(modifier = Modifier.height(16.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            tabs.forEach { tab ->
                val isSelected = selectedTab == tab
                Text(
                    text = tab,
                    color = if (isSelected) Color(0xFFFF3F6C) else Color.Gray,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier
                        .clickable { selectedTab = tab }
                        .padding(bottom = 4.dp)
                )
            }
            Icon(Icons.Outlined.GridView, contentDescription = null, tint = Color.DarkGray)
        }

        // 4. Icons Categories (Replaced images with icons as requested)
        Spacer(modifier = Modifier.height(12.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp)) {
            items(DataRepository.getCategories()) { category ->
                Column(
                    modifier = Modifier.padding(end = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .border(1.dp, Color.LightGray.copy(alpha = 0.5f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = category.icon,
                            contentDescription = null,
                            tint = Color(0xFFFF3F6C),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Text(category.name, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp), fontWeight = FontWeight.Medium)
                }
            }
        }

        // 5. Promotional Banner
        Spacer(modifier = Modifier.height(16.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .height(50.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFFFF3F6C)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "FLAT ₹400 OFF   USE CODE: MYNTRA400",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        // 6. Main Banners (Updated with shopping-related images)
        Spacer(modifier = Modifier.height(16.dp))
        DataRepository.getMainBanners().forEach { banner ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(350.dp)
                    .padding(bottom = 16.dp)
            ) {
                AsyncImage(
                    model = banner.imageUrl,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f))
                            )
                        )
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (banner.title != null) {
                        Text(banner.title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    if (banner.subtitle != null) {
                        Text(banner.subtitle, color = Color.White, fontSize = 14.sp)
                    }
                }
            }
        }

        // 7. Most-Loved Bargains
        Text(
            "Most-Loved Bargains",
            modifier = Modifier.padding(16.dp),
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF900C3F)
        )
        
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
        ) {
            DataRepository.getMostLovedBargains().take(4).forEach { deal ->
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    AsyncImage(
                        model = deal.imageUrl,
                        contentDescription = null,
                        modifier = Modifier
                            .aspectRatio(0.75f)
                            .clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Text(deal.price, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                    Text(deal.title, fontSize = 10.sp, color = Color.Gray)
                }
            }
        }
        
        Spacer(modifier = Modifier.height(100.dp))
    }
}
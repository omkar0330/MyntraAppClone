package com.example.myntraapp.ui.theme

import androidx.compose.ui.graphics.Color

val OceanBluePrimary = Color(0xFF006D77)
val SoftTeal = Color(0xFF83C5BE)
val SandBackground = Color(0xFFEDF6F9)
val CoralAccent = Color(0xFFE29578)
val DarkText = Color(0xFF2C3E50)
val LightText = Color(0xFF95A5A6)